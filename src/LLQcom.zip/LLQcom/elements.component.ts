import { Component, Inject } from '@angular/core';
import { MatButton, MatIcon, MatMenu} from '@angular/material';

/**
 * MAIN MENU, LINKS, TOP PAGE AND FOOTER
 */
@Component({
  selector: 'menu-main',
  template: `
  <div fxLayout="row" fxLayoutAlign="space-around">
    <button mat-raised-button class="z-index-high back-green text-light" [matMenuTriggerFor]="menuAbout">About Legal LinQ</button>
    <button mat-raised-button class="z-index-high text-light" color="warn" [matMenuTriggerFor]="menuAutoDS">Decision Support</button>
    <button mat-raised-button class="z-index-high back-green text-light" [matMenuTriggerFor]="menuLegal">Legal advice</button>
  </div>
  <mat-menu #menuAbout="matMenu" [overlapTrigger]="false"><about_component></about_component></mat-menu>
  <mat-menu #menuAutoDS="matMenu" [overlapTrigger]="false"><AutoDS></AutoDS></mat-menu>
  <mat-menu #menuLegal="matMenu" [overlapTrigger]="false"><JuridischAdvies></JuridischAdvies></mat-menu>
`,
//styles: [``],
}) export class MenuMainComponent {}

/**
 * MENU FOOTER, LINKS TO PAGE
 */
@Component({
  selector: 'menu-footer',
  template: `
<div id="menuFooter" fxLayout="row wrap" fxLayoutAlign="center" >
  <a title="Homepage van Legal LinQ" [routerLink]=" ['./']" class="text-light">Home</a>
  <a title="Privacy statement" [routerLink]=" ['./privacy']" class="text-light">Privacy statement</a>
  <a title="Informatie over Legal LinQ" [routerLink]=" ['./about']" class="text-light">About Legal LinQ</a>
  <a title="Contact informatie" [routerLink]=" ['./contact']" class="text-light">Contact</a>
</div>
`,
  styles: [`
    #menuFooter a{
      cursor:pointer;
      margin:1vw;
    }
  `],
}) export class MenuFooterComponent {}


/**
 * MOBILE MENU
 */
@Component({
  selector: 'menu-mobile',
  templateUrl: 'elements.Menu-Mobile.html',
 // styles: [``],
}) export class MenuMobileComponent {}

/**
 * ABOUT COMPONENT
 */
@Component({
  selector: 'about_component',
  templateUrl: 'elements.About.html',
}) export class AboutComponent {}

/**
 * PRIVACY statement COMPONENT
 */
@Component({
  selector: 'privacy_component',
  template: `
  <h1>Privacy statement</h1>
  <p>This site uses cookies of Google Analytics. Please refer to <a href="http://www.google.nl/intl/nl/policies/privacy/" target="_blank">privacy statement</a> of Google.</p>
  <p>Further this site does not collect any data other than needed for a correct functioning of the site.</p>
 `,
}) export class PrivacyComponent {}

/**
 * CONTACT COMPONENT
 */
@Component({
  selector: 'contact_component',
  templateUrl: 'elements.Contact.html',
}) export class ContactComponent {}

/**
 * AUTO DECISION SUPPORT
 */
@Component({
  selector: 'AutoDS',
  template: `HEEEEE geen html meer`,
}) export class AutoDSComponent {}

/**
 * Juridisch advies
 */
@Component({
  selector: 'JuridischAdvies',
  templateUrl: 'elements.JurAdvies.html',
}) export class JuridischAdviesComponent {}
