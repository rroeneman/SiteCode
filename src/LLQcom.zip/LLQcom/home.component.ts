import { Component } from '@angular/core';
import {MatToolbar} from '@angular/material';
import {MediaChange, ObservableMedia} from '@angular/flex-layout';
import { Router } from '@angular/router';

@Component({
  selector: 'home_component',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
})
export class HomeComponent{
  constructor(
    private router:Router,
    public media: ObservableMedia, //for responsiveness
  ) { }
}
