import { Component, HostListener, Inject } from "@angular/core";
import { DOCUMENT } from '@angular/platform-browser';

//Theming, a Menu
import {MatToolbar, MatButton} from '@angular/material';
//import {MdSidenavModule} from '@angular/material';

@Component({
  selector: 'apphome',
  templateUrl: 'app.component.html',
  styles: [require('../styles.scss')],
}) 
export class AppComponent{
  public toolbarIsSticky: boolean = false;
  constructor( @Inject(DOCUMENT) private document: Document ) {}
  
  @HostListener("window:scroll", [])
  onWindowScroll() {
    let number = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
    if (number > 37) {
      this.toolbarIsSticky = true;
    } else if (this.toolbarIsSticky && number < 36) {
      this.toolbarIsSticky = false;
    }
  }
}