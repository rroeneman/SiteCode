import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';

//ELECTRON
import {NgxElectronModule} from 'ngx-electron';

//theming
import { MatButtonModule, MatDialogModule, MatMenuModule, MatIconModule, MatSidenavModule, MatToolbarModule } from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import 'hammerjs'; //gesture support

// App is our top level component
import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { AboutComponent, ContactComponent, DialogComponent, MenuMainComponent, MenuMobileComponent, PrivacyStatementComponent } from './elements.component';
import { PageNotFoundComponent } from './page-not-found.component';

import { LocalStorageModule } from 'angular-2-local-storage'; 

//Routing
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';
const appRoutes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about', component: HomeComponent },
  { path: 'contact', component: ContactComponent },
  //{ path: 'decision-support/:id', loadChildren: '../+survey#SurveyModule' },
  //{ path: 'decision-support', loadChildren: '../+survey#SurveyModule' },
  {
    path: 'decision-support',
    loadChildren: () => import('../+survey/survey.module')
      .then(module => module['SurveyModule'], () => { throw({ loadChunkError: true }); })
  },
  { path: '404', component: PageNotFoundComponent },
  { path: '**', redirectTo: '/404' }
];

@NgModule({
  declarations: [ AppComponent,
                  HomeComponent,
                  AboutComponent, ContactComponent, DialogComponent, MenuMainComponent, MenuMobileComponent, PrivacyStatementComponent, 
                  PageNotFoundComponent,
                  ],
  imports: [  BrowserModule,
              BrowserAnimationsModule,
              FlexLayoutModule,
              MatButtonModule, MatDialogModule, MatMenuModule, MatIconModule, MatSidenavModule, MatToolbarModule,
              LocalStorageModule.withConfig({
                prefix: 'llqdrp',
                storageType: 'localStorage'
              }),
              CommonModule,
              NgxElectronModule,
              RouterModule.forRoot(appRoutes, {useHash:true, preloadingStrategy: PreloadAllModules}) //LET OP: PRELOADING GEBEURT HIER, ZIE https://toddmotto.com/lazy-loading-angular-code-splitting-webpack
            ],
  providers:[],
  entryComponents: [DialogComponent],
  bootstrap:[ AppComponent ]
})
export class AppModule {
}