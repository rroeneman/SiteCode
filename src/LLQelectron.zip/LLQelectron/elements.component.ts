import { Component, Inject } from '@angular/core';
import { MatButton, MatDialog, MatDialogActions, MAT_DIALOG_DATA, MatIcon, MatMenu} from '@angular/material';

/**
 * MAIN MENU, LINKS, TOP PAGE AND FOOTER
 */
@Component({
  selector: 'menu-main',
  template: `
<div fxLayout="row" fxLayoutAlign="space-between stretch">
  <a mat-button href="#" title="Homepage of Legal LinQ" class="active">Home</a>
  <a mat-button (click)="openDialog('about')" title="About Legal LinQ">About Legal LinQ</a>
  <a mat-button (click)="openDialog('contact')" title="Contact details">Contact</a>
</div>
`,
  //styles: [``],
})
export class MenuMainComponent {   constructor( public dialog: MatDialog) {}
      //Open popup window en keyword object er naar toe
      openDialog(linkref:any) {this.dialog.open(DialogComponent, {width:'500px', data: {options:linkref,} });}
}
/**
 * MOBILE MENU
 */
@Component({
  selector: 'menu-mobile',
  //templateUrl: require('./elements.menu-mobile.html'),
  templateUrl: 'elements.menu-mobile.html',
 // styles: [``],
})
export class MenuMobileComponent { constructor( public dialog: MatDialog) {}
//Open popup window en keyword object er naar toe
openDialog(linkref:any) {this.dialog.open(DialogComponent, {width:'500px', data: {options:linkref,} });}}

/**
 * DIALOG BOX, FOR CONTACT AND OTHER FIELDS
 */
@Component({
  selector: 'mainpage-dialogbox',
  template: `
    <div [ngSwitch]="data.options">
      <ng-template [ngSwitchCase]="'about'"> <about_component></about_component> </ng-template>
      <ng-template [ngSwitchCase]="'contact'"> <contact_component></contact_component> </ng-template>
      <ng-template [ngSwitchCase]="'privacy'"> 
        <h2>Privacy statement</h2>
        <p>This website uses cookies of Google Analytics. Please see <a href="https://policies.google.com/?hl=en-GB" target="_blank">privacy statement</a> of Google.</p>
        <p>This site further only collects data that is necessary for its correct functioning.</p>
      </ng-template>
    </div>
    <mat-dialog-actions><button  mat-fab color="primary" mat-dialog-close="save">OK</button></mat-dialog-actions> 
  `,
})
export class DialogComponent {
  constructor(  @Inject(MAT_DIALOG_DATA) public data: { options : any,}, ) {} }

/**
 * ABOUT COMPONENT
 */
@Component({
  selector: 'about_component',
  template: `
    <h2>Over Legal LinQ</h2>
    <p>Legal LinQ is a small specialized legal advisory firm run by Mr. Jeroen Knijpenga (LLM, MCIArb).</p> 
    <p>Please see also <a href="https://nl.linkedin.com/in/jknijpenga/">LinkedIn</a>.</p>
    <p>Mr. Jeroen Knijpenga (LLM, MCIArb)</p>
  `,
})
export class AboutComponent {}

/**
 * CONTACT COMPONENT
 * 
 */
@Component({
  selector: 'contact_component',
  template: `
  <h2>Contact details</h2>
  <p>Legal LinQ is gevestigd in Haarlem.</p>  
  <p><em>Legal LinQ has its principal place of business in Haarlem, The Netherlands.</em></p>
  <p>U kunt ons bereiken per: / <em>You can reach us via:</em>
    <a href="mailto:info@legallinq.nl?subject=request from the website"> e-mail .</a>
  <p>KvK registratie no: 59112441</p>
  <p><em>Registered at the trade register of the Chamber of Commerce in Amsterdam, file no: 59112441</em>
  `,
})
export class ContactComponent {}

/**
 * PRIVACY STATEMENT
 */
@Component({
  selector: 'privacy-statement',
  template: ` <a (click)="openDialog('privacy')" style="cursor:pointer;" title="Privacy statement">Privacy statement</a>`,
})
export class PrivacyStatementComponent {   constructor( public dialog: MatDialog) {}
      //Open popup window en keyword object er naar toe
      openDialog(linkref:any) {this.dialog.open(DialogComponent, {width:'500px', data: {options:linkref,} });}
}