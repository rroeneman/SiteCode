import { Component } from "@angular/core";

@Component({
  selector: 'apphome',
  templateUrl: 'app.component.html',
  styles: [require('../styles.scss')],
}) 
export class AppComponent{}