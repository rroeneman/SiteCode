import { Component, OnInit } from '@angular/core';

//ELECTRON
import {ElectronService} from 'ngx-electron';
const path = require('path');
const fs = require('fs'); 
import { LocalStorageService } from 'angular-2-local-storage';

import {MatToolbar, MatIcon} from '@angular/material';
import { Router } from '@angular/router';

//LOAD OFFLINE SCRIPTS, TO INCLUDE THEM IN WEBPACK BUNDLE (beetje slordig maar dan zijn ze er tenminste)
import '../../assets/externalscripts/jszip.min.js';
import '../../assets/externalscripts/docxtemplater-latest.min.js';

@Component({
  selector: 'home_component',
  //templateUrl: require('./home.component.html'),
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
})
export class HomeComponent  implements OnInit {
  constructor(
    private router:Router,
    private _electronService: ElectronService,
    private localStorageService: LocalStorageService,
  ) { }

  ngOnInit(){
    var glb = this;
    this.fetchElectronData();
    setTimeout(function(){ glb.router.navigate(['/decision-support/ebmt90210']); }, 3000);
  }
  //Communicate with electron main, to get info from system (win/mac)
  fetchElectronData() {
    //https://electronjs.org/docs/api/ipc-renderer
    if(this._electronService.isElectronApp) {
      
      //request to send back the reply      
      this._electronService.ipcRenderer.send('asynchronous-message', 'ping');   
      //reply should have all commandline arguments, starting with the path
      this._electronService.ipcRenderer.on('asynchronous-reply', (event:any, args:any) => {
        console.log("Command line arguments: ",args)
        this.loadConfigData(path.dirname(args[0]));
      });

    }
  }
  //load data file with config from disk
  loadConfigData(filepath:String){
    var global = this;
    console.log("Path of Angular project", process.cwd())
    console.log("Path that runs electron APP",filepath);
    
    var p = path.join('assets', 'Fullconfig.json');
    fs.readFile(p, function (err:any, data:any) {
      if (err) return console.error(err);
      let DataObj:object = JSON.parse(data);
      console.log(DataObj);
      //setTimeout(function(){ this.fullDataHandler(DataObj); }, 3000);
      global.fullDataHandler(DataObj);
    }); 
  }
	/**
	 * SPLIT THE AGGREGATED OBJECT AND SEND TO STORAGE FUNCTION
	 */	
	fullDataHandler(DataObj:object){
    this.localStorageService.clearAll(); //clear all the data
		this.StoreData(DataObj['Q'],"");
		this.StoreData(DataObj['A'],"Result");
    this.StoreData(DataObj['C'],"Config");
    return true;
	}
	/**
	 * STORE QUESTIONS AND RESULTS
	 * @param DataObj = een object parsed from JSON
	 * @param prefix = the prefix for the key
	 */
	 StoreData(DataObj:object, prefix:String){
		//find all keys, which will become file names
		var ListOfQuestionHashes = Object.keys(DataObj);

		var i:any;
		for (i = 0; i < ListOfQuestionHashes.length; i++) {
			let name =ListOfQuestionHashes[i]; //file names, these are the hash keys
			let value = DataObj[ListOfQuestionHashes[i]]; //the actual json for the form schema
			this.localStorageService.set(prefix+name, value);
		}
		console.log("Data loaded into local storage",DataObj);
		return true; //send true back to activate re-loading of page
	}
}