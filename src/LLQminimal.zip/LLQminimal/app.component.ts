import { Component } from '@angular/core';

@Component({
  selector: 'apphome',
  template: `
    <h1>Hello World</h1>
  `
})
export class AppComponent {

}
